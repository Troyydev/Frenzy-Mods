local Glock19 = {
 prefabAddress = 'Assets/Example/RelisticPack/Prefabs/RealisticPistol.prefab',
 displayName = 'Glock-19'
}
local RealisticAK47 = {
 prefabAddress = 'Assets/Example/RelisticPack/Prefabs/RealisticAK-47.prefab',
 displayName = 'AK-47'
}
weaponTable[Glock19.prefabAddress] = Glock19
weaponTable[RealisticAK47.prefabAddress] = RealisticAK47