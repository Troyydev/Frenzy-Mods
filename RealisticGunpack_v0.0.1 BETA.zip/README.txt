QUEST:
Drag RealisticGunPackQUEST
Android/data/com.InnoverseLtd.FrenzyVR/files/LocalMods
(might have to make LocalMods)
PC:
No clue dont use the PC version but its provided at
RealisticGunPackPC